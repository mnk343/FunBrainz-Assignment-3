#include "StdAfx.h"
#include "shape_defination.h"

