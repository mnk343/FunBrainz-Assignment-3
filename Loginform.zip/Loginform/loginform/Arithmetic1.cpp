#include "StdAfx.h"
#include "Arithmetic1.h"
